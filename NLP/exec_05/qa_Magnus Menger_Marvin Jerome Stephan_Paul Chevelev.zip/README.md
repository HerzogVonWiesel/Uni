Python 3.9.16

pip install -r requirements.txt

Then simply run the .py file.